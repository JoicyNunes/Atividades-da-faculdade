create database pw09;

use pwn;

create table produto(
codigo bigint auto_increment
primary key,
titulo varchar(100),
descritivo varchar(100),
valor varchar(100),
quantidade varchar(100),
categoria varchar(100));

select * from produto; 
