<!--Joicy Da Silva Nunes-->
<!DOCTYPE html>
<html>
    <body>
        <h1>Produto</h1>
        <a href="listaProduto.php">Voltar para a lista de produto</a><br/>
        <form method="post" action="produto.php">
            Codigo:
            <input type="number" id="codigo" name="codigo"/><br/>

            
            Titulo:
            <input type="text" id="titulo" name="titulo"/></br>

            Descritivo:
            <input type="text" id="descritivo" name="descritivo"/><br/>

            Valor:
            <input type="text" id="valor" name="valor"/><br/>


            Quantidade:
            <input type="text" id="quantidade" name="quantidade"/><br/>

            Categoria:
            <input type="text" id="categoria" name="categoria"/><br/>

            <button name="btn1">Inserir</button>
            <button name="btn2">Pesquisar</button>
            <button name="btn3">Alterar</button>
            <button name="btn4">Remover</button>
        </form> 
        <?php
            if(isset($_POST["btn1"])) Inserir();
            if(isset($_POST["btn2"])) Pesquisar($_POST["codigo"]);
            if(isset($_POST["btn3"])) Alterar();
            if(isset($_POST["btn4"])) Remover();
            if(isset($_GET["codigo"])) Pesquisar($_GET["codigo"]);
        ?>
    </body>
</html>

<?php
    function Inserir(){
        $titulo = $_POST["titulo"];
        $descritivo = $_POST["descritivo"];
        $valor = $_POST["valor"];
        $quantidade = $_POST["quantidade"];
        $categoria = $_POST["categoria"];
        $con = new mysqli("localhost", "root", "123456", "pwn");
        $sql = "insert into produto(titulo, descritivo, valor, quantidade, categoria) values('$titulo', '$descritivo', '$valor', '$quantidade', '$categoria')";
        mysqli_query($con, $sql);
        mysqli_close($con);
        echo "<h4>Produto registrado com sucesso</h4>";
    }
    function Pesquisar($codigo){
        $con = new mysqli("localhost", "root", "123456", "pwn");
        $sql = "select * from produto where codigo='$codigo'";
        $retorno = mysqli_query($con, $sql);
        if($reg = mysqli_fetch_array($retorno)){
            echo "<script lang='javascript'>";
            echo "codigo.value='".     $reg["codigo"]      ."';";
            echo "titulo.value='".     $reg["titulo"]      ."';";
            echo "valor.value='".      $reg["valor"]       ."';";
            echo "descritivo.value='". $reg["descritivo"]  ."';";
            echo "quantidade.value='". $reg["quantidade"]  ."';";
            echo "categoria.value='".  $reg["categoria"]   ."';";
            echo "</script>";
        } else {
        echo "<h4>Produto não existe</h4>";
        }
        mysqli_close($con);
    }
    function Alterar(){
        $codigo = $_POST["codigo"];
        $titulo = $_POST["titulo"];
        $descritivo = $_POST["descritivo"];
        $valor = $_POST["valor"];
        $quantidade = $_POST["quantidade"];
        $categoria = $_POST["categoria"];
        $con = new mysqli("localhost", "root", "123456", "pwn");
        $sql = "update produto set titulo='$titulo', descritivo='$descritivo', valor='$valor', quantidade='$quantidade', categoria='$categoria' where codigo='$codigo'";
        mysqli_query($con, $sql);
        mysqli_close($con);
        echo "<h4>Produto alterado com sucesso</h4>";
    }
    function Remover(){
        $codigo = $_POST["codigo"];
        $con = new mysqli("localhost", "root", "123456", "pwn");
        $sql = "delete from produto where codigo='$codigo'";
        mysqli_query($con, $sql);
        mysqli_close($con);
        echo "<h4>Produto removido com sucesso!</h4>";
    }
?>